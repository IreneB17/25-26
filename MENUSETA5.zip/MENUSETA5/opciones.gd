extends Control




func _on_volumen_pressed() -> void:
	get_tree().change_scene_to_file("res://VOLUMEN.tscn")




func _on_creditos_pressed() -> void:
	get_tree().change_scene_to_file("res://CREDITOS.tscn")




func _on_atras_pressed() -> void:
	get_tree().change_scene_to_file("res://menu.tscn")
